package Consts;

public class Consts {
    public static final String MAIN_URL = "https://kidkiddos.com/";
    public static final String MAIN_URL2 = "https://kidkiddos.com/";
    public static final String MAIN_URL3 = "https://kidkiddos.com/";

}
